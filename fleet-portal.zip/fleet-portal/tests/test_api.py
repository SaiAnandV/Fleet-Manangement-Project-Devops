import os
import tempfile
import unittest

from app import create_app


class FleetApiTests(unittest.TestCase):
    def setUp(self):
        self.dir = tempfile.TemporaryDirectory()
        self.c = create_app(os.path.join(self.dir.name, "t.db")).test_client()

    def tearDown(self):
        self.dir.cleanup()

    def vehicle(self, reg="TS09AB1234", **extra):
        return self.c.post("/api/vehicles", json={"reg_number": reg, "make": "Tata", "model": "Ace", **extra})

    def test_health(self):
        self.assertEqual(self.c.get("/api/health").json["status"], "ok")

    def test_vehicle_crud_and_validation(self):
        r = self.vehicle(year=2021)
        self.assertEqual(r.status_code, 201)
        vid = r.json["id"]
        self.assertEqual(self.vehicle().status_code, 409)
        self.assertEqual(self.c.post("/api/vehicles", json={"make": "x"}).status_code, 400)
        ok = self.c.put(f"/api/vehicles/{vid}", json={"reg_number": "TS09AB1234", "make": "Tata",
                        "model": "Ace", "status": "In Service"})
        self.assertEqual(ok.status_code, 200)
        self.assertEqual(self.c.get(f"/api/vehicles/{vid}").json["status"], "In Service")
        self.assertEqual(self.c.get("/api/vehicles?q=ace").json[0]["id"], vid)
        self.assertEqual(self.c.delete(f"/api/vehicles/{vid}").status_code, 204)
        self.assertEqual(self.c.get(f"/api/vehicles/{vid}").status_code, 404)

    def test_maintenance_flow_and_dashboard(self):
        vid = self.vehicle().json["id"]
        m = self.c.post("/api/maintenance", json={"vehicle_id": vid, "service_type": "Oil change",
                        "service_date": "2020-01-01", "cost": 1500})
        self.assertEqual(m.status_code, 201)
        self.assertEqual(self.c.get("/api/dashboard").json["overdue"], 1)
        self.c.patch(f"/api/maintenance/{m.json['id']}/complete")
        d = self.c.get("/api/dashboard").json
        self.assertEqual((d["overdue"], d["total_cost"]), (0, 1500))
        bad = self.c.post("/api/maintenance", json={"vehicle_id": vid, "service_type": "x", "service_date": "bad"})
        self.assertEqual(bad.status_code, 400)

    def test_driver_assignment(self):
        did = self.c.post("/api/drivers", json={"name": "Ravi", "license_no": "DL1"}).json["id"]
        vid = self.vehicle("AP01", driver_id=did).json["id"]
        self.assertEqual(self.c.get(f"/api/vehicles/{vid}").json["driver_name"], "Ravi")


if __name__ == "__main__":
    unittest.main()
